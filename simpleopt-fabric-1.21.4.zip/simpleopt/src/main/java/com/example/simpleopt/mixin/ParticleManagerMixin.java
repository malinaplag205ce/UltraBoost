package com.example.simpleopt.mixin;

import com.example.simpleopt.SimpleOpt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void simpleopt$cullFarParticles(ParticleEffect effect, double x, double y, double z,
                                            double vx, double vy, double vz,
                                            CallbackInfoReturnable<Particle> cir) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.gameRenderer == null) return;
        Vec3d cam = client.gameRenderer.getCamera().getPos();
        double max = SimpleOpt.PARTICLE_MAX_DISTANCE;
        if (cam.squaredDistanceTo(x, y, z) > max * max) {
            cir.setReturnValue(null);
        }
    }
}
