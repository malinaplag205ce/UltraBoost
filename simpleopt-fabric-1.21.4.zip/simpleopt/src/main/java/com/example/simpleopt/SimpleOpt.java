package com.example.simpleopt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.ChunkPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SimpleOpt implements ModInitializer {
    // ===== Настройки (меняйте и пересобирайте) =====
    public static final int CHECK_INTERVAL_TICKS = 200;   // раз в 10 секунд
    public static final int MAX_ITEMS_PER_WORLD = 300;    // лимит предметов на земле
    public static final int MAX_MOBS_PER_TYPE_PER_CHUNK = 24;
    public static final double PARTICLE_MAX_DISTANCE = 48.0; // блоков, клиент

    @Override
    public void onInitialize() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getTime() % CHECK_INTERVAL_TICKS != 0) return;
            trimItems(world);
            trimMobs(world);
        });
    }

    private static void trimItems(ServerWorld world) {
        List<ItemEntity> items = new ArrayList<>();
        for (Entity e : world.iterateEntities()) {
            if (e instanceof ItemEntity item) items.add(item);
        }
        if (items.size() <= MAX_ITEMS_PER_WORLD) return;
        // Сначала удаляем самые старые
        items.sort(Comparator.comparingInt(ItemEntity::getItemAge).reversed());
        int toRemove = items.size() - MAX_ITEMS_PER_WORLD;
        for (int i = 0; i < toRemove; i++) items.get(i).discard();
    }

    private static void trimMobs(ServerWorld world) {
        Map<Long, Map<EntityType<?>, Integer>> counts = new HashMap<>();
        for (Entity e : world.iterateEntities()) {
            if (!(e instanceof MobEntity mob)) continue;
            // Не трогаем именованных, прирученных, на поводке и "постоянных" мобов
            if (mob.hasCustomName() || mob.isPersistent() || mob.isLeashed()
                    || mob instanceof TameableEntity) continue;
            long key = new ChunkPos(mob.getBlockPos()).toLong();
            int n = counts.computeIfAbsent(key, k -> new HashMap<>())
                    .merge(mob.getType(), 1, Integer::sum);
            if (n > MAX_MOBS_PER_TYPE_PER_CHUNK) mob.discard();
        }
    }
}
