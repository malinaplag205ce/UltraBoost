Сборка:
1. Установите JDK 21 и Gradle (или скопируйте папку wrapper из официального шаблона Fabric).
2. В папке проекта: gradle wrapper --gradle-version 8.12
3. ./gradlew build   (Windows: gradlew.bat build)
4. Готовый jar: build/libs/simpleopt-1.0.0.jar -> в папку mods
Нужен Fabric API для 1.21.4.
